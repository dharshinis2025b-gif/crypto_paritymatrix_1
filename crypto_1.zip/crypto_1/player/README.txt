THE BROKEN TRANSMISSION
An unknown device transmitted a classified message. The device is gone;
only its temporary storage was recovered. The transmission is corrupted.

  evidence/   recovered files
  encrypted/  the captured payload

Find the flag. Format: CTF{...}
